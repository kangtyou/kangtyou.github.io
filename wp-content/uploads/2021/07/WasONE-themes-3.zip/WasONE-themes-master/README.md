## 我编写的第一个 `WordPress` 模板主题 `WasONE-themes`

### 前言

​	所以，我就去寻找一款完全遵循完全开源 `CMS `建站系统 于是乎，了解到了 `WordPress`，他是遵循 GNU通用公共许可证下授权发布的 完全开源程序，然后我就开始了学习 `WordPress` 旅程，我处理学习他的基本操作之外，我还更多，想了解一下，他的运作原理以及，参与他的提供的让开发者可以创造出，完全属于自己的主题和功能插件，官方提供了很多参考资料和学习渠道，虽然是国外建站系统，应为他的易用和开源，收到了国内开发者追捧，在国内也有不少关于 `WordPress` 高手们的本土化教程资料和视频，我经过一段时间学习和研究后也写出了一个，完全属于自己的 前端主题，知道今日不断完善我的主题推出了 `1.8 版本`。

```
Theme Name: WasONE-themes( White and simple )
Theme URI: https://www.52dreamsky.cn
Author:  JasonLee
Author URI: https://www.52dreamsky.cn
Description: 	
Version: 1.8 优化 Puls 版( 稳定版 )
Tags: 简约、白色、两栏布局、漂亮
```

### 更新记录

1. 2019年

<div id="sousuo" class="sousuo">
    <label class="screen-reader-text" for="s"></label>
    <form class="hvr-wobble-vertical">
        <input type="text" value="<?php the_search_query(); ?>" name="s" id="s"  placeholder="search...">
        <button type="submit"></button>
    </form>
</div>